package com.example.HannipmanApp;

import com.opencsv.CSVReader;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class CSVDataLoader {

    @Autowired
    private RestaurantRepo restaurantRepo;

    @PostConstruct
    public void loadDataFromCSVAndImages() {
        String csvFilePath = "src/main/resources/data/restaurantDB.csv";
        String imageDirectoryPath = "src/main/resources/images/";

        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
            String[] line;
            reader.readNext(); // 헤더 건너뛰기

            while ((line = reader.readNext()) != null) {

                // 식당 이름으로 중복검사
                String restaurantName = line[2];
                if (restaurantRepo.existsByName(restaurantName)) {
                    System.out.println("중복된 레스토랑: " + restaurantName);
                    continue; // 이미 존재하면 해당 데이터를 건너뛰고 다음 데이터로 넘어감
                }

                Restaurant restaurant = new Restaurant();
                restaurant.setDiary(line[1].equals("1"));
                restaurant.setName(line[2]);
                restaurant.setMenu(Arrays.asList(line[3].split(",")));
                restaurant.setPrice(parsePrices(line[4]));
                restaurant.setRating(Double.parseDouble(line[5]));
                restaurant.setKategorie(line[6]);
                restaurant.setPhoneNumber(line[7]);
                restaurant.setBusinessHours(line[8]);
                restaurant.setClosedDays(line[9]);
                restaurant.setBreakTime(line[10]);
                restaurant.setKiosk(line[11]);
                restaurant.setPlace(line[12]);
                restaurant.setLatitude(Double.parseDouble(line[13]));
                restaurant.setLongitude(Double.parseDouble(line[14]));

                // 이미지 파일 읽어오기
                String imageFileName = line[0] + ".jpg"; // 예: "1.jpg"
                File imageFile = new File(imageDirectoryPath + imageFileName);
                if (imageFile.exists()) {
                    byte[] imageData = FileCopyUtils.copyToByteArray(new FileInputStream(imageFile));
                    restaurant.setImage(imageData);
                } else {
                    System.out.println(imageFileName + " 파일을 찾을 수 없습니다.");
                }

                restaurantRepo.save(restaurant);
            }
            System.out.println("CSV 데이터와 이미지를 성공적으로 저장했습니다!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private List<Integer> parsePrices(String priceData) {
        String[] prices = priceData.split(",");
        List<Integer> priceList = new ArrayList<>();
        for (String price : prices) {
            priceList.add(Integer.parseInt(price));
        }
        return priceList;
    }
}

