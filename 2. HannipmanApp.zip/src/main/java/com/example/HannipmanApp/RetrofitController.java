package com.example.HannipmanApp;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/restaurants") // API의 기본 경로 설정
public class RetrofitController {

    private final RestaurantRepo restaurantRepo;

    // Repository를 주입 받습니다.
    public RetrofitController(RestaurantRepo restaurantRepo) {
        this.restaurantRepo = restaurantRepo;
    }

    // 모든 Restaurant 데이터 반환
    @GetMapping
    public List<Restaurant> getAllRestaurants() {
        return restaurantRepo.findAll(); // Repository를 통해 모든 데이터를 반환
    }

    // 특정 ID의 Restaurant 데이터 반환
    @GetMapping("/{id}")
    public Restaurant getRestaurantById(@PathVariable Long id) {
        return restaurantRepo.findById(id).orElseThrow(() ->
                new RuntimeException("Restaurant not found with id: " + id)
        );
    }

    // 새로운 Restaurant 데이터 생성
    @PostMapping
    public Restaurant createRestaurant(@RequestBody Restaurant restaurant) {
        return restaurantRepo.save(restaurant); // 새로운 데이터 저장
    }
}
