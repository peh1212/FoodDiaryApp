package com.example.hannipmanapp;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.os.Bundle;
import android.util.Log;

import androidx.fragment.app.FragmentActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private RestaurantService restaurantService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Retrofit 초기화
        restaurantService = RetrofitClient.getInstance().create(RestaurantService.class);

        // SupportMapFragment를 얻고, 지도를 비동기적으로 초기화
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    // 지도가 준비되었을 때 호출
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // 서버에서 레스토랑 위치 데이터 가져오기
        restaurantService.getRestaurantLocations().enqueue(new Callback<List<RestaurantDTO>>() {
            @Override
            public void onResponse(Call<List<RestaurantDTO>> call, Response<List<RestaurantDTO>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    for (RestaurantDTO restaurant : response.body()) {
                        LatLng location = new LatLng(restaurant.getLatitude(), restaurant.getLongitude());
                        mMap.addMarker(new MarkerOptions().position(location).title(restaurant.getName()));
                    }
                    if (!response.body().isEmpty()) {
                        LatLng firstLocation = new LatLng(response.body().get(0).getLatitude(), response.body().get(0).getLongitude());
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(firstLocation, 10));
                    }
                }
            }

            @Override
            public void onFailure(Call<List<RestaurantDTO>> call, Throwable t) {
                // 실패 시 처리
                Log.e("Retrofit", "Failed to fetch restaurant locations", t);
            }
        });
    }
}
