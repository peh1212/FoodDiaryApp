package com.example.hannipmanapp;

public class RestaurantDTO {
    private Double latitude;
    private Double longitude;
    private String name;

    // 기본 생성자
    public RestaurantDTO() {
    }

    // 파라미터가 있는 생성자
    public RestaurantDTO(Double latitude, Double longitude, String name) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.name = name;
    }

    // Getter와 Setter 메서드
    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
