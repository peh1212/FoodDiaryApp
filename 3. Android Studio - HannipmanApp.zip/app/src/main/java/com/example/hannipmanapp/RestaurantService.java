package com.example.hannipmanapp;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface RestaurantService {
    @GET("/restaurants/locations")
    Call<List<RestaurantDTO>> getRestaurantLocations();
}
