package com.example.HannipmanApp;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Restaurant {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String name;

    @ElementCollection
    private List<String> menu;

    @ElementCollection
    private List<Integer> price;

    @Column
    private Double rating;

    @Column
    private Double latitude;

    @Column
    private Double longitude;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] image;
}

interface RestaurantRepo extends JpaRepository<Restaurant, Long> {
    boolean existsByName(String name);
}

@Data
@AllArgsConstructor
@NoArgsConstructor
class RestaurantDTO {
    private Double latitude;
    private Double longitude;
    private String name;
}
